package com.amrita.jpl.cys21027.practice.basicprograms;

/**
 * @author K Sri Sai Nitin
 * @version 0.5
 */

public class HelloWorld {
    /**
     * Main method that prints "Hello world!" to the console.
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}