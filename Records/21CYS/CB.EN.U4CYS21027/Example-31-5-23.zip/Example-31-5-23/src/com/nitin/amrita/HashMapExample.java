package com.nitin.amrita;

import java.util.HashMap;

/**
 * The HashMapExample class demonstrates the usage of HashMap to store and retrieve roll numbers and names.
 * It creates a HashMap to associate roll numbers with corresponding names.
 * This class provides a basic example of working with HashMap in Java.
 *
 * Usage:
 * - The program creates a HashMap called rollName to store roll numbers and names.
 * - It adds key-value pairs (roll numbers and names) to the HashMap using the put() method.
 * - It retrieves the value (name) associated with a specific key (roll number) using the get() method.
 * - It prints the retrieved name.
 *
 * Note: This example uses a HashMap of strings to represent roll numbers and names.
 *
 * Dependencies:
 * - None
 *
 * @author Ramaguru Radhakrishnan
 * @version 0.5
 */
public class HashMapExample {
    /**
     * The main method is the entry point of the program.
     * It demonstrates the usage of HashMap to store and retrieve roll numbers and names.
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {
        // Create a HashMap object called rollName
        HashMap<String, Integer> CarModelPrice = new HashMap<String, Integer>();

        // Add keys and values (roll numbers and names) to the HashMap
        CarModelPrice.put("Lamborghini GT", 6000450 );
        CarModelPrice.put("Ferrari GT Sport",3848450 );
        CarModelPrice.put("Honda Civic Sport",9832450 );
        CarModelPrice.put("Skyline GT Nissan",3400450 );
        CarModelPrice.put("Buggati Veyron",9342450 );
        CarModelPrice.put("Maserati Quattroporte",9830450 );
        CarModelPrice.put("BMW Z4",7230450 );
        CarModelPrice.put("Alfa Romeo 4C",65300450 );
        CarModelPrice.put("Aston Martin Vantage",8500450 );

        System.out.println(CarModelPrice.get("Skyline GT Nissan"));
    }
}
