package com.amrita.jpl.cys21027.ex;

import java.util.Scanner;

interface Calculator {
    double add(double a, double b);
    double subtract(double a, double b);
    double multiply(double a, double b);
    double divide(double a, double b);
}

class BasicCalculator implements Calculator {

    public double add(double a, double b) {
        return a + b;
    }

    public double subtract(double a, double b) {
        return a - b;
    }

    public double multiply(double a, double b) {
        return a * b;
    }

    public double divide(double a, double b) {
        if (b != 0) {
            return a / b;
        } else {
            throw new ArithmeticException("Division by zero error!");
        }
    }
}


public class Calculator_Interface {

    public static void main(String[] args) {

        Calculator calculator = new BasicCalculator();

        Scanner scanner = new Scanner(System.in);
        double num1 = scanner.nextDouble();
        double num2 = scanner.nextDouble();

        double sum = calculator.add(num1, num2);
        double difference = calculator.subtract(num1, num2);
        double product = calculator.multiply(num1, num2);
        double quotient = 0;


        System.out.println("Addition: " + sum);
        System.out.println("Subtraction: " + difference);
        System.out.println("Multiplication: " + product);
        try {
            quotient = calculator.divide(num1, num2);
        } catch (ArithmeticException e) {
            System.out.println(e.getMessage());
            quotient = -1;
        }
        System.out.println("Division: " + quotient);

        scanner.close();
    }
}