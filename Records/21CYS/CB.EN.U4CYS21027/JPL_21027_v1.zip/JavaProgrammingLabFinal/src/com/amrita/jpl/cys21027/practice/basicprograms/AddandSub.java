package com.amrita.jpl.cys21027.practice.basicprograms;

import java.util.Scanner;

public class AddandSub
{
    public static void main(String args[])
    {
        int a, b, add, sub;
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter First Number : ");
        a = scanner.nextInt();
        System.out.print("Enter Second Number : ");
        b = scanner.nextInt();

        add = a + b;
        sub = a - b;

        System.out.println("Sum of "+a+ " and " +b+ " = " + add);
        System.out.println("Difference of "+a+ " and " +b+ " = " + sub);

    }
}