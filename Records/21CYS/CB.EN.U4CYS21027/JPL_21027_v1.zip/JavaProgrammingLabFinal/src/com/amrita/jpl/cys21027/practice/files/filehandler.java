package com.amrita.jpl.cys21027.practice.files;
import java.util.Scanner;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/**
 * The CreateFileExample class demonstrates how to create a file using the File class.
 * It creates a new file with a specified name and displays a success message if the file is created successfully.
 * This class provides a basic structure for creating files in Java.
 *
 * Usage:
 * - The program specifies the name of the file to create.
 * - It creates a File object with the specified filename.
 * - It calls the createNewFile() method to create the file.
 * - If the file is created successfully, it displays a success message.
 * - If the file already exists, it displays a message indicating that the file already exists.
 *
 * Note: This example assumes that the file can be created in the specified location.
 *
 * Dependencies:
 * - None
 *
 * @author K Sri Sai Nitin
 * @version 0.5
 */

public class filehandler {
    public static void main(String[] args) {

        /**
         * The main method is the entry point of the program.
         * It creates a new file with a specified name and displays a success message if the file is created successfully.
         *
         * @param args command line arguments
         */

        try {
           File myFile = new File("20cys383.txt");
            if (myFile.createNewFile()) {
                System.out.println("File created: " + myFile.getName());
            } else {
                System.out.println("[INFO] File Exists.");
            }
            System.out.println("Absolute path: " + myFile.getAbsolutePath());
            System.out.println("Writeable: " + myFile.canWrite());
            System.out.println("Readable " + myFile.canRead());
            System.out.println("File size in bytes " + myFile.length());
            System.out.println("Hash Code" + myFile.hashCode());
            FileWriter myWriter = new FileWriter("20cys383.txt");
            myWriter.write("Files in Java might be tricky, but it is fun enough!");
            myWriter.close();

            /**
             * The ReadFileExample class demonstrates how to read a text file using the Scanner class.
             * It reads the contents of a file line by line and displays them on the console.
             * This class provides a basic structure for reading files in Java.
             *
             * Usage:
             * - The program specifies the filename to read.
             * - It creates a File object using the specified filename.
             * - It creates a Scanner object to read from the file.
             * - The program iterates through the file line by line using a while loop.
             * - For each line, it retrieves the data and prints it to the console.
             * - Finally, it closes the Scanner.
             *
             * Note: This example assumes that the file exists and is readable.
             *
             * Dependencies:
             * - None
             *
             */

            /**
             * The main method is the entry point of the program.
             * It reads the contents of a text file and displays them on the console.
             *
             * @param args command line arguments
             */

            //File myFile  = new File("20cys383.txt");
            //Scanner myScan = new Scanner(myFile);
            //while(myScan.hasNextLine()){
            //    String d = myScan.nextLine();
            // System.out.println(d);
            //}
        }
        catch (IOException e) {
            System.out.println("[ERROR] Input Output Exception");
            e.printStackTrace();
        }
    }
}