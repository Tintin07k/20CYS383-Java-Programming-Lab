package com.amrita.jpl.cys21027.practice.classes;

import java.util.Scanner;
/**
 * The CalculatorAbstract class is an abstract class that defines the common behavior for different shapes.
 * It declares an abstract area() method and provides a default implementation for the display() method.
 * This class serves as a base for implementing specific shape classes.
 *
 * Usage:
 * - Subclasses should provide an implementation for the area() method.
 * - The display() method can be used to display information common to all shapes.
 *
 * Note: This example includes Addition,Subtraction,Division,Multiplication that inherit from the Shape class.
 *
 * Dependencies:
 * - None
 *
 * @author K Sri Sai Nitin
 * @version 0.5
 */
abstract class CalculatorAbstract {
    /**
     * Calculates the operation.
     * Subclasses must provide their own implementation.
     */
    abstract double calculate(double n1, double n2);
}
class Addition extends CalculatorAbstract {
    double calculate(double n1, double n2) {
        return n1 + n2;
    }
}

class Subtraction extends CalculatorAbstract {
    double calculate(double n1, double n2) {
        return n1 - n2;
    }
}

class Multiplication extends CalculatorAbstract {
    double calculate(double n1, double n2) {
        return n1 * n2;
    }
}

class Division extends CalculatorAbstract {
    double calculate(double n1, double n2) {
        if (n2 != 0) {
            return n1 / n2;
        } else {
            System.out.println("Cannot divide by zero");
        }
        return 0;
    }
}
public class Calculator_Abstract {
    /**
     * The main method is the entry point of the program.
     * It demonstrates the usage of abstract classes and inheritance.
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double num1, num2;
        int choice;

        System.out.print("Enter the first number: ");
        num1 = scanner.nextDouble();

        System.out.print("Enter the second number: ");
        num2 = scanner.nextDouble();

        System.out.println("Select an operation:");
        System.out.println("1. com.java.calc_abstract.Addition");
        System.out.println("2. com.java.calc_abstract.Subtraction");
        System.out.println("3. com.java.calc_abstract.Multiplication");
        System.out.println("4. com.java.calc_abstract.Division");
        System.out.print("Enter your choice : ");
        choice = scanner.nextInt();
        CalculatorAbstract calculator;
        switch (choice) {
            case 1:
                calculator = new Addition();
                break;
            case 2:
                calculator = new Subtraction();
                break;
            case 3:
                calculator = new Multiplication();
                break;
            case 4:
                calculator = new Division();
                break;
            default:
                System.out.println("Invalid choice. Exiting...");
                return;
        }

        double result = calculator.calculate(num1, num2);
        System.out.println("Result: " + result);
    }
}