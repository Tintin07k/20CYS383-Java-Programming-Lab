package com.amrita.jpl.cys21027.ex;

class Vehicle{

    protected boolean run_status;

    public void start(){
        run_status = true;
        System.out.println("[Vehicle] started.");
    }

    public void stop(){
        run_status = false;
        System.out.println("[Vehicle] stopped.");
    }
}

class Car extends Vehicle {
    private String modelname;
    private int year;
    private int numofwheels;

    public Car(String modelname,int year,int numofwheels){
        this.modelname = modelname;
        this.year = year;
        this.numofwheels = numofwheels;
        System.out.println("Car Instantiated with Parameter " + modelname + ", " + year + ", " + numofwheels);
    }

    public void drive(int gear_position){
        if (run_status) {
            System.out.println("Driving the car in gear position: " + gear_position);
        } else {
            System.out.println("Error: The car is not running.");
        }
    }

}


class Bike extends Vehicle {
    private String brandname;
    private int year;
    private int numofgears;

    public Bike(String brandname, int year, int numofgears) {
        this.brandname = brandname;
        this.year = year;
        this.numofgears = numofgears;
        System.out.println("Bike Instantiated with Parameter " + brandname + ", " + year + ", " + numofgears);
    }

    public void pedal(int pedal_speed) {
        if (run_status) {
            System.out.println("Pedaling the bike at speed: " + pedal_speed);
        } else {
            System.out.println("Error: The bike is not running.");
        }

    }
}


public class Vehicle_Inheritance {
    public static void main(String[] args) {
        Car car = new Car("Jaguar XF", 2022, 4);
        car.start();
        car.drive(3);
        car.stop();
        Bike bike = new Bike("Giant", 2021, 18);
        bike.start();
        bike.pedal(10);
        bike.stop();
    }

}