#include <iostream>
using namespace std;
int main() 
{
   cout << "Hello, World!"; // This prints Hello, World!
   return 0;
}