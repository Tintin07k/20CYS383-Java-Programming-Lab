/*
#include<iostream>
class student
{
	private:
		int b;
		int h;
		//float x;
	public:
		void area(int b,int h)
		{
			x=0.5 * b * h;
			std::cout<< x <<'\n';
		}
		
};
int main()
{
	student t,d;
	t.area(3,5);// As the member function is public, we can access it.
	//d.print(97);
	//std::cin>>t.mark;
	//std::cout << t.mark;
	return 0;
}
*/
#include<iostream>
class student
{
	private:
		int b;
		int h;
		//float x;
	public:
		void area(int b,int h)
		{
			x=0.5 * b * h;
			std::cout<< x <<'\n';
		}
		
};
int main()
{
	student t,d;
	t.area(3,5);// As the member function is public, we can access it.
	//d.print(97);
	//std::cin>>t.mark;
	//std::cout << t.mark;
	return 0;
}

