//Inheritance 
//Multi Level Inheritance - process where an inherited class is further made as a parent class to another class

#include<iostream>
using namespace std;
class Shape
{
  public:
    int a;
    int b;
    void get_data(int n,int m)
    {
      a=n;
      b=m;
    }
};
class Rectangle : public Shape
{
  public:
    int rect_area()
    {
      int result = a*b;
      return result;
    }
};

class Color : public Rectangle
{
    public:
     void color(){
         string col;
         cout<<"Enter the colour of rectangle: ";
         cin>>col;
         cout<<"Colour is : "<<col;
     }
};
int main()
{
  Color r;
  int length,breadth;
  cout<<"Enter the length of a rectangle: ";
  cin>>length;
  cout<<"Enter the breadth of a rectangle: ";
  cin>>breadth;
  r.get_data(length,breadth);
  int m = r.rect_area();
  cout<<"Area of the rectangle is : "<<m<<endl;
  r.color();
  return 0;
}


/*

#include <iostream>
#include <string>
using namespace std;
 
class colourRectangle {
    public:
    string color;
    float leth;
    float brth;
    colourRectangle(string str, float a, float b){
        color = str;
        leth = a;
        brth = b;
        }
    void getArea(){
        cout << leth * brth;
    }
    void getColour(){
        cout << color;
    }
    };
 
int main(){
colourRectangle r1("Red",2,3.5);
cout << "Area: ";
r1.getArea();
cout<< "   " << "Colour: ";
r1.getColour();
 
cout << endl;
 
colourRectangle r2("blue",2.987,3.569);
cout<<"Area: "; 
r2.getArea();
cout<< "   " << "Colour: ";
r2.getColour();
cout << endl;
return 0;
}
*/