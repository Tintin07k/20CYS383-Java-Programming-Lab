#include<iostream>
using namespace std;
class parent{
    public:
    parent()//constructor
    {
        cout<<"Parent class constructor\n";
    }
    ~parent(){
        cout<<"Parent class destructor\n";
    }
};

    class child : public parent{
    public:
    child(){
        cout<<"Child class constructor\n";
    }
    ~child(){
        cout<<"Child class destructor\n";
    }
};


int main(){
    child c;
    return 0;
}

/*Parent class Constructor
Child Class constructor
Child class destructor
Parent class destructor
*/






//POinter to the object 
//POinter for Data Member of class 