//Base class - Array_Details
//Derived class - functions 
//A[10]- Data members
//Member Function - Read array


//Derived class has no datamembers but has member functions like sort(), add all elements(), find largest(), find smallest(),
//sum of digits of each element(), factorial of each element(),


#include<iostream>
using namespace std;

class Array_Details
{
  public:
  int a[10];
  int i;
  int size;
  int b;
  void readarray(){
    cout<<"Enter the values of the element: ";
    for(i=0;i<10;i++)
    {
    cin>>a[i];
  }

   }
};


class Function : public Array_Details
{
    public:
    int sort(int b[10],int size){
    int i,j,c;
    for(int i=0; i<size; ++i)
		{
			for(int j=i+1; j<size; ++j)
				{
					if(b[i]>b[j])
						{
							c=b[i];
							b[i]=b[j];
							b[j]=c;
						}
				}
		}
		cout<<endl<<"the sorted values are"<<endl;
		for(int i=0; i<size; i++)
			
				cout<<b[i]<<" ";
                return 0;
			}

};


int main(){
    Array_Details g;
    Function h;
    g.readarray();
    h.sort(g.a,10);
};
