#include <iostream>
using namespace std;
int main()
{
 cout << "Size of char : " << sizeof(char);
 cout << "Size of int : " << sizeof(int);
 return 0;
}