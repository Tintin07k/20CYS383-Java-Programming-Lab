#include<iostream>
using namespace std;

class array_Details
{
public:
	int a[10];
	void readarray()
	{
		int i;
		cout<<"Enter the value of the element: "<<endl;
		for(i=0;i<10;i++)
		{
			cin>>a[i];
		}
	}
};
class functions : public array_Details
{
public:
	int sort(int b[10],int size)
	{
	int i,j,temp;
    for (i = 0; i < size; ++i)
    {
        for (j = i + 1; j < size; ++j)
        {
            if (b[i] > b[j])
            {
                temp =  b[i];
                b[i] = b[j];
                b[j] = temp;
            }
        }
    }
    cout<<"Sorting Order Array: \n";
    for (i = 0; i < size; ++i)
        cout<<b[i]<<endl;
    return 0;
	}
};
int main()
{
	array_Details m;
	functions n;
	m.readarray();
	n.sort(m.a,10);
	return 0;
	
}