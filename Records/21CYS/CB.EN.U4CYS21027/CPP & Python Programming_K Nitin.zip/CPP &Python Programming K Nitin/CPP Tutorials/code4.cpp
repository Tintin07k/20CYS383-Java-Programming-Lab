#include <iostream>
using namespace std;
 
int main()
{
	int num1, num2, sum;
    cout << "\n Sum of two numbers :\n";
	cout << "-------------------------\n";   
	cout << " Input 1st number : ";
	cin >> num1 ;
	cout << " Input 2nd number : ";
	cin >> num2;
	sum = num1 + num2;
	cout <<" The sum of the numbers is : " << sum << endl;
	cout << endl;
	return 0;
}