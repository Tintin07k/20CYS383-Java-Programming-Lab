//parameterized const of base class

#include <iostream>
using namespace std;
class Base{
    int x;
    public:
    Base()          //constructor 
    { 
        cout<<"Base\n";

    }
    Base(int i){
        cout<<"Base parameterized constructor"<<i<<"\n";

    }
};

class Derived : public Base{
    int y;
    public:
    Derived():Base(30)
    {
        cout<<"Derived Constructor\n";
    }                                                             //parameterized constructor
    Derived(int i):Base(20){
        cout<<"Derived parameterized constructor"<<i<<"\n";
    }
};

int main(){
    Base b1;
    Base b2(20);
    Derived d1;
    Derived d2(10);
}
/* Base 
Base parametterized const - 20
Base parameterized const -30
Derived constructor 
Base parameterized constructor - 20
Derived constructor parameterized - 10 */


