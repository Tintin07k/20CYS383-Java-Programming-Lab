//Polymorphism

//Overloading- Compile time(early binding)  Function Overloading and Operator Overloading
// and Overriding-Runtime(Late binding)


