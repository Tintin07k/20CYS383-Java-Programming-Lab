#include <iostream>
using namespace std;
 
 
int main()
{
    cout << "\n\n Print the sum of two numbers :\n";
	cout << "-----------------------------------\n";
	int a;
	int b;
	int sum;
	a=29;
	b=30;
	sum=a+b;
	cout << " The sum of "<< a << " and "<<b <<" is : "<< sum <<"\n\n" ;
}