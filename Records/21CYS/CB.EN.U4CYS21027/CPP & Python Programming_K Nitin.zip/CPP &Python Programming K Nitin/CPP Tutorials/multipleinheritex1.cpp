#include<iostream>
using namespace std;
class Mammals{
    public:
    void f1(){
        cout<<"I am a Mammal"<<endl;
    }
};

class MarineAnimals{
    public:
    void f2(){
        cout<<"I am a Marine Animal"<<endl;
    }
};

class BlueWhale: public Mammals, public MarineAnimals{
    public:
    void f3(){
        cout<<"I belong to both categories : Mammals and Marine Animals."<<endl;
    }
};

int main(){
    Mammals ma;
    MarineAnimals mr;
    BlueWhale bw;
    ma.f1();
    mr.f2();
    bw.f3();
    bw.f2();
    bw.f1();
    return 0;
}