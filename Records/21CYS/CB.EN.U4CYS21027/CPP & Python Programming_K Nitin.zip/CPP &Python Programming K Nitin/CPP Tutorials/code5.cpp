#include<iostream>
using namespace std;
struct student 
{
    int mark;
};
int main()
{
    student t;
    t.mark=10;
    cout<<t.mark;
    return 0;
}