/* C++ program to demonstrate call by value,call by reference and call by address */
#include<iostream>
using namespace std;

// call by value or pass by value
void passbyValue(int x, int y)
{
	int z;
	z=x;
	x=y;
	y=z;
}
int main()
{
	int a=5,b=6;
	cout<<"Before swapping"<<endl<<"a:"<<a<<endl<<"b:"<<b<<endl;
	passbyValue(a,b);
	
	cout<<"After swapping"<<endl<<"a:"<<a<<endl<<"b:"<<b<<endl;
	return 0;
	//The change doesn't be replicated to the main function
}
