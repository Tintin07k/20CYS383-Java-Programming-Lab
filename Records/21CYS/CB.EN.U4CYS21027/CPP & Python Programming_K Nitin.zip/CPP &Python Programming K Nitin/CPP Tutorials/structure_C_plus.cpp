#include<iostream>
struct student
{
	int mark=30;
};
int main()
{
	student t;
	std::cout<<t.mark;
	return 0;
}
