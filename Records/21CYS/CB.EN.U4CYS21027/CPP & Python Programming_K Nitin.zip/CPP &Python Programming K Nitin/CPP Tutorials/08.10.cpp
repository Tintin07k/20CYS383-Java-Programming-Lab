//CLASSES METHODS AND OBJECTS 

/*class classname {

......
..........
.....
};                  //CLASS SYNTAX    */


#include<iostream>
using namespace std;

class test{
int code; //attribute normal(member)
static int count;  //static attribute (member)
public:
void setcode()  //member function 1 accessing static attribute //static member can be used to access all member functions
{
   code = count++;
}
void showcode() //member function 2
{
   cout<<"object number: "<<code<<endl;
}
static void showcount()  //member function 3 static member function
{
    cout<<"count: "<<count<<endl;
}
};

int test :: count=10;  //scope resolution operator making static attribute(member) = 10 
 
int main()
{
test t1,t2;
t1.setcode();
t2.setcode();
test :: showcount();     //static members are common to all of the member functions
test t3;
t3.setcode();
test :: showcount();
t1.showcode();
t2.showcode();
t3.showcode();
return 0;
}




