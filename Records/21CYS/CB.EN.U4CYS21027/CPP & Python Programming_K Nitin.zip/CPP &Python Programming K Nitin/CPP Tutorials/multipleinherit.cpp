//multiple inheritance - 

// Base Class --> Derived class 1--> n no of derived class will continue(Derived Class 2)
// base classes -------> Derived Class
//Hierarchial Inheritance - Tree structure 

//Base Classs ----> Derived class 1 ----->Derived Classes 2
                                    //|----> Derived Class 3

//Hybrid Classess - multiple dderived classes will have a single derived class.


#include<iostream>
using namespace std;

class A{

private:
int P1;
protected:
int Aa;
public:
int Ab;
A(){
    P1=100;
    Aa=10;
    Ab=20;
    cout<<"Inside Class A"<<endl;
}
void display(){
    cout<<"Value of private variable P1 is"<<P1<<endl;
    cout<<"Value of protected variable Aa is"<<Aa<<endl;
    cout<<"Value of public variable Ab is"<<Ab<<endl;

}
};

class B{

private:
int P2;
protected:
int Ba;
public:
int Bb;
B(){
    P2=70;
    Ba=50;
    Bb=80;
}
void display(){
    cout<<"Value of private variable P2 is:"<<P2<<endl;
    cout<<"Value of protected variable Ba is:"<<Ba<<endl;
    cout<<"Value of public variable Bb is:"<<Bb<<endl;
}
};

class C{

private:
int P3;
protected:
int Ca;
public:
int Cb;
C(){
    P3=59;
    Ca=78;
    Cb=40;    
}
void display(){
    cout<<"Value of private variable P3 is:"<<P3<<endl;
    cout<<"Value of protected variable Ca is:"<<Ca<<endl;
    cout<<"Value of public variable Cb is:"<<Cb<<endl;
}

};

 class D:public A,private C,protected B{
    public:
    D(){
        cout<<"Inside class D"<<endl;
    }
    void sum(){
        cout<<"The sum of all the accessible variables derived from base classes A,B,C is:"<<Aa+Ab+Ba+Bb+Ca+Cb<<endl;

    }

    void display(){
        cout<<"Private variable P1 derived from class A is not accessible in Class D"<<endl;
        cout<<"Protected Variable Aa derived from class A is protected in Class D"<<endl;
        cout<<"Public variable Ab derived from class A is public in Class D"<<endl;

        cout<<"Private variable P2 derived from class B is not accessible in Class D"<<endl;
        cout<<"Protected variable Ba derived from class B is protected in Class D"<<endl;
        cout<<"Public variable Bb derived from class B is protected in Class D"<<endl;

        cout<<"Private variable P1 derived from class A is not accessible in Class D"<<endl;
        cout<<"Protected variable Ca derived from class A is private in Class D"<<endl;
        cout<<"Public variable Cb derived from class A is private in Class D"<<endl;
    }



};


int main(){
    A a;
    a.display();
    B b;
    b.display();
    C c;
    c.display();
    D d;
    d.display();
    d.sum();
    cout<<"Public Variable Ab derived from Class A is public in class D and is allowed to access it."<<endl;
    return 0;
}