a = 5
print("Type of a: ", type(a))
b = 5.0
print(" nType of b: ", type(b))
c = 2 + 4j
print(" nType of c: ", type(c))




a = ="Hello,
print(a[1])

b = ="Hello,
print(b[2:5])

b = ="Hello,
print(b[ 5: 2])

a = ="Hello,
print( len (a))


a = =" Hello, World!
print( a.strip ())
print( a.lower())
print( a.split (","))


thislist = ["apple", "banana", "cherry", "orange", "kiwi",
"melon"]
print( thislist [2:5])


x = ("apple", "banana", "cherry")
y = list(x)
y[1] = "kiwi"
x = tuple(y)
print(x)

            
