class planet:
    var1 = "Planet"
    var2 = "Solar system"

    def function(self):
        print("I'm earth")
        print("I'm a", self.var1, "in", self.var2)


earth = planet()
print(earth.var1)
print(earth.var2)
earth.function()


class Compute:
 def area(self, x = None, y = None):
  if x != None and y != None:
   return x * y
  elif x != None:
    return x * x
  else:
      return 0
obj = Compute()
print("Area Value:",obj.area())
print("Area Value:",obj.area (4))
print("Area Value:",obj.area (3,5))


class Point:
 def __init__(self,a,b):
     self.a= a
     self.b= b
 def __str__(self):
     return self.a , self.b
 def __add__(self, other):
     return self.a + other.a ,self.b + other.b
Ob1 = Point(1, 2)
Ob2 = Point(2, 3)
Ob3 = Ob1 + Ob2
print(Ob3)