class Person:
 def __init__(self, name, age):
  self.name = name
  self.age = age
 def myfunc(self):
  print("Hello my name is " + self.name)

p1 = Person("John", 36)
p1.myfunc()


a = 2
print('id(a) =',id(a))
a = a+1
print('id(a) =',id(a))
print('id(3) =',id(3))
b = 2
print('id(b) =',id(b))
print('id(2) =',id(2))


