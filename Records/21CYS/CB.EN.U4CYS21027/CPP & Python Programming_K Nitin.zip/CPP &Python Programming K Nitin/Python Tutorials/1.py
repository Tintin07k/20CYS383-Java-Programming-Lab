#Inheritance in Python
'''
class Parent1():
 def show(self):
  print("Inside Parent1")

class Parent2():
 def display(self):
  print("Hello")

class Child(Parent1, Parent2):
 def show(self):
   print("Inside Child") 


obj = Child()
obj.show()
obj.display()

'''
'''
#Multilevel Inheritance

class Grandfather:
 def __init__(self, grandfathername):
   self.grandfathername = grandfathername


class Father(Grandfather):
 def __init__(self, fathername, grandfathername):
  self.fathername = fathername

  Grandfather.__init__(self, grandfathername)

class Son(Father):
  def __init__(self,sonname, fathername, grandfathername):
    self.sonname = sonname
    Father.__init__(self, fathername, grandfathername)

def print_name(self):
 print('Grandfather name :', self.grandfathername)
 print("Father name :", self.fathername)
 print("Son name :", self.sonname)

s1 = Son('Prince', 'Rampal','Lal mani')
print(s1.grandfathername)
s1.print_name()
'''




class Student:
    school_name = 'ABC SCHOOL'  #class variable - common to all objects

#Constructor:

def __init__(self,name,age):
    #instance variables
    self.name = name
    self.age = age

#instance variables

def show(self):
    print(self.name,self.age,Student.school_name)

#Class Method,Static Method and Member functions
#Class Variables and Instance Attributes

