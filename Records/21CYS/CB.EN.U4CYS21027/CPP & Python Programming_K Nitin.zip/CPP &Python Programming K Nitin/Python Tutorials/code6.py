class Dog:

    attr1 = "mammal"
    attr2 = "dog"
    def fun(self):
        print("I'm a", self.attr1)
        print("I'm a", self.attr2)

Rodger = Dog()
print(Rodger.attr1)
Rodger.fun()



class Bike:
    name = ""
    gear = 0

bike1 = Bike()

bike1.gear = 11
bike1.name = "Mountain Bike"

print(f"Name: {bike1.name}, Gears: {bike1.gear} ")





class Employee:
    employee_id = 0

employee1 = Employee()
employee2 = Employee()

employee1.employeeID = 1001
print(f"Employee ID: {employee1.employeeID}")
employee2.employeeID = 1002
print(f"Employee ID: {employee2.employeeID}")










class Rectangle:
 def __init__(self, length, breadth, unit_cost=0):
  self.length = length
  self.breadth = breadth
  self.unit_cost = unit_cost
 def get_perimeter(self):
  return 2 * (self.length + self.breadth)
 def get_area(self):
  return self.length * self.breadth
 def calculate_cost(self):
  area = self.get_area()
  return area * self.unit_cost
r = Rectangle(160, 120, 2000)
print("Area of Rectangle: %s cm^2" % (r.get_area()))
print("Cost of rectangular field: Rs. %s " %(r.calculate_cost()))



