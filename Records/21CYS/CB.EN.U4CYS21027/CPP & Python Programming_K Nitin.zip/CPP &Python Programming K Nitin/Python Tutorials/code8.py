class Employee:

 def __init __(self, name, sal):
     self.name = name;
     self.sal = sal;

emp = Employee("Ironman", 999000);
print(emp.sal)


class Person:
 def __init __(self, name,age):
     self.name = name
     self.age= age
 def myfunc (self):
    print("Hello my name is " + self.name)

print ("Person.__doc __:", Person.__doc__)
print ("Person.__name __:", Person.__name__)
print ("Person.__module __:", Person.__module__)
print ("Person.__bases __:", Person.__bases__)
print ("Person.__dict __:", Person.__dict__)