x='global'
def f():
 x='enclosing'
def g():
 x='local'
print(x)
g()
print(x)
f()
print(x)


def f():
 x='enclosing'
 def g():
   x='local'
   print(x)
g()
f()


