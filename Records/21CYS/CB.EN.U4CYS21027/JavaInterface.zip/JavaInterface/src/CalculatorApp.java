import java.util.Random;
import java.util.Scanner;

interface Calculator{
  int add(int num1,int num2);
  int subtract(int num1,int num2);
  int multiply(int num1,int num2);
  int divide(int num1,int num2);

}
class BasicCalc implements Calculator{

    @Override
    public int add(int num1, int num2) {
        return num1+num2;
    }

    @Override
    public int subtract(int num1, int num2) {
        return num1-num2;
    }

    @Override
    public int multiply(int num1, int num2) {
        return num1*num2;
    }

    @Override
    public int divide(int num1, int num2) {
        if(num2==0){
            System.out.println("Enter valid denominator!!!!!");
        }
        return num1/num2;
    }
}

public class CalculatorApp {
    public static void main(String[] args) {
        Calculator calculator = new BasicCalc();
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the first number: ");
        int a = scanner.nextInt();

        System.out.print("Enter the second number: ");
        int b = scanner.nextInt();

        int result;
        System.out.println("Enter your choice(+,-,*,/): ");
        int op = scanner.nextInt();
        switch(op){
            case 1:
                result = calculator.add(a,b);
                System.out.println("The addition is : "+result);
                break;
            case 2:
                result = calculator.subtract(a,b);
                System.out.println("The subtraction is : "+result);
                break;

            case 3:
                result = calculator.multiply(a,b);
                System.out.println("The Multiplication is : "+result);
                break;

            case 4:
                result = calculator.divide(a,b);
                System.out.println("The Division is : "+result);
                break;

            default:
                System.out.println("Enter correct number!!!!");
        }

    }
}